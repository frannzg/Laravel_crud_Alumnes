

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="text-center mb-4">
        <h1><?php echo e(__("Llistat de Ensenyaments")); ?></h1>
        <a href="<?php echo e(route('ensenyament.create')); ?>" class="btn btn-primary">
            <?php echo e(__("Afegir Ensenyament")); ?>

        </a>
    </div>

    <div class="mb-3">
        <a href="<?php echo e(url('/home')); ?>" class="btn btn-secondary">Darrere</a>
    </div>

    <table class="table table-bordered mb-5 mt-3">
        <thead>
            <tr class="table-success">
                <th><?php echo e(__("Id")); ?></th>
                <th><?php echo e(__("Nom")); ?></th>
                <th><?php echo e(__("Accions")); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $ensenyaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ensenyament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row"><?php echo e($ensenyament->id); ?></th>
                    <td><?php echo e($ensenyament->nom); ?></td>
                    <td>
                        <a href="<?php echo e(route('ensenyament.edit', $ensenyament)); ?>" class="btn btn-warning"><?php echo e(__("Editar")); ?></a> 
                        <a href="#" class="btn btn-danger" onclick="event.preventDefault(); document.getElementById('delete-ensenyament-<?php echo e($ensenyament->id); ?>-form').submit();"><?php echo e(__("Eliminar")); ?></a>
                        <form id="delete-ensenyament-<?php echo e($ensenyament->id); ?>-form" action="<?php echo e(route('ensenyament.destroy', $ensenyament)); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center">
                        <strong><?php echo e(__("No hi ha ensenyaments")); ?></strong>
                        <span><?php echo e(__("No hi ha cap dada a mostrar")); ?></span>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    
    <div class="d-flex justify-content-center">
        <?php echo $ensenyaments->links(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario.DESKTOP-F8NFSKL\Desktop\crud\resources\views/ensenyament.blade.php ENDPATH**/ ?>