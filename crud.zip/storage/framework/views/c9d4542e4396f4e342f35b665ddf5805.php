<div class="w-full">
    <div class="flex flex-wrap">
        <h1 class="mb-5"><?php echo e($title ?? 'Ensenyament'); ?></h1>
    </div>
</div>

<form method="POST" action="<?php echo e($route); ?>" class="needs-validation">
    <?php echo csrf_field(); ?>
    <?php if(isset($update)): ?>
        <?php echo method_field("PUT"); ?>
    <?php endif; ?>
    <div class="mb-3">
        <label for="nom" class="form-label"><?php echo e(__("Nom")); ?></label>
        <input name="nom" type="text" class="form-control" value="<?php echo e(old('nom') ?? ($ensenyament->nom ?? '')); ?>">
        <?php $__errorArgs = ["nom"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="fs-6 text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-3">
        <button class="btn btn-primary" type="submit">
            <?php echo e($textButton); ?>

        </button>
    </div>

    <div class="mb-3">
        <a href="<?php echo e(route('ensenyament.index')); ?>" class="btn btn-secondary">Darrere</a>
    </div>
</form>
<?php /**PATH C:\Users\Usuario.DESKTOP-F8NFSKL\Desktop\crud\resources\views/ensenyament/form.blade.php ENDPATH**/ ?>