
<?php $__env->startSection("content"); ?>
<div class="container mt-5">
    <?php echo $__env->make("centre.form", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario.DESKTOP-F8NFSKL\Desktop\crud\resources\views/centre/edit.blade.php ENDPATH**/ ?>