

<?php $__env->startSection("content"); ?>

<div class="container mt-5">
    <div class="text-center">
        <h1><?php echo e(__("Llistat d'alumnes")); ?></h1>
        <a href="<?php echo e(route("alumne.create")); ?>" class="btn btn-primary">
            <?php echo e(__("Afegir alumne")); ?>

        </a>
    </div>

    <div class="mb-3">
        <a href="http://127.0.0.1:8000/home" class="btn btn-secondary">Darrere</a>
    </div>

    <table class="table table-bordered mb-5 mt-5">
        <thead>
            <tr class="table-success">
                <th><?php echo e(__("Id")); ?></th>
                <th><?php echo e(__("Nom")); ?></th>
                <th><?php echo e(__("Cognoms")); ?></th>
                <th><?php echo e(__("Data naixement")); ?></th>
                <th><?php echo e(__("Centre")); ?></th>
                <th><?php echo e(__("Ensenyament")); ?></th> <!-- Nueva columna añadida -->
                <th><?php echo e(__("Accions")); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $alumnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <th scope="row"><?php echo e($alumne->id); ?></th>
                <td><?php echo e($alumne->nom); ?></td>
                <td><?php echo e($alumne->cognoms); ?></td>
                <td><?php echo e(date_format(new DateTime($alumne->data_naixement), "d/m/Y")); ?></td>
                <td><?php echo e($alumne->centre->nom ?? __('No especificat')); ?></td>
                <td><?php echo e($alumne->ensenyament->nom ?? __('No especificat')); ?></td> <!-- Mostrar el ensenyament -->
                <td>
                    <a href="<?php echo e(route("alumne.edit", ["alumne" => $alumne])); ?>" class="btn btn-warning"><?php echo e(__("Editar")); ?></a> 
                    <a href="#" class="btn btn-danger" onclick="event.preventDefault(); document.getElementById('delete-project-<?php echo e($alumne->id); ?>-form').submit();"><?php echo e(__("Eliminar")); ?></a>
                    <form id="delete-project-<?php echo e($alumne->id); ?>-form" action="<?php echo e(route("alumne.destroy", ["alumne" => $alumne])); ?>" method="POST" class="hidden">
                        <?php echo method_field("DELETE"); ?>
                        <?php echo csrf_field(); ?>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6">
                    <div class="text-center" role="alert">
                        <p><strong class="font-bold"><?php echo e(__("No hi ha alumnes")); ?></strong></p>
                        <span><?php echo e(__("No hi ha cap dada a mostrar")); ?></span>
                    </div>
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>

    
    <div class="d-flex justify-content-center">
        <?php echo $alumnes->links(); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Usuario.DESKTOP-F8NFSKL\Desktop\crud\resources\views/alumne.blade.php ENDPATH**/ ?>