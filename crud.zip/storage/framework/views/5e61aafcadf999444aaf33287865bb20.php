<div class="w-full">
    <div class="flex flex-wrap">
        <h1 class="mb-5"><?php echo e($title); ?></h1>
    </div>
</div>

<form method="POST" action="<?php echo e($route); ?>" class="needs-validation">
    <?php echo csrf_field(); ?>
    <?php if(isset($update)): ?>
    <?php echo method_field("PUT"); ?>
    <?php endif; ?>
    <div class="mb-3">
        <label for="nom" class="form-label"><?php echo e(__("Nom")); ?></label>
        <input name="nom" type="text" class="form-control" value="<?php echo e(old("nom") ?? $alumne->nom); ?>">
        <?php $__errorArgs = ["nom"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="fs-6 text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
        <label for="cognoms" class="form-label"><?php echo e(__("Cognoms")); ?></label>
        <input name="cognoms" type="text" class="form-control" value="<?php echo e(old("cognoms") ?? $alumne->cognoms); ?>">
        <?php $__errorArgs = ["cognoms"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="fs-6 text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
        <label for="data_naixement" class="form-label"><?php echo e(__("Data de naixement")); ?></label>
        <input name="data_naixement" type="date" class="form-control" value="<?php echo e(old("data_naixement") ?? $alumne->data_naixement); ?>">
        <?php $__errorArgs = ["data_naixement"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="fs-6 text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
        <label for="centre_id" class="form-label"><?php echo e(__("Centre")); ?></label>
        <select class="form-select" name="centre_id" value="<?php echo e(old("centre_id") ?? $alumne->centre_id); ?>">
            <?php $__currentLoopData = $centres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($centre->id); ?>" <?php echo e($centre->id == $alumne->centre_id ? 'selected' : ''); ?>><?php echo e($centre->nom); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ["centre_id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="fs-6 text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-3">
        <label for="ensenyament_id" class="form-label"><?php echo e(__("Ensenyament")); ?></label>
        <select id="ensenyament_id" class="form-select" name="ensenyament_id">
            <option value=""><?php echo e(__("Selecciona un ensenyament")); ?></option>
            <?php $__currentLoopData = $ensenyaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ensenyament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($ensenyament->id); ?>" <?php echo e((old('ensenyament_id', $alumne->ensenyament_id ?? '') == $ensenyament->id) ? 'selected' : ''); ?>>
                    <?php echo e($ensenyament->nom); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ["ensenyament_id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="fs-6 text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    


    <div class="mb-3">
        <button class="btn btn-primary" type="submit">
            <?php echo e($textButton); ?>

        </button>
    </div>

    <div class="mb-3">
        <a href="http://127.0.0.1:8000/alumne" class="btn btn-secondary">Darrere</a>
    </div>
</form><?php /**PATH C:\Users\Usuario.DESKTOP-F8NFSKL\Desktop\crud\resources\views/alumne/form.blade.php ENDPATH**/ ?>