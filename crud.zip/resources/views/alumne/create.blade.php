@extends("layouts.app")
@section("content")
<div class="container mt-5">
    @include("alumne.form")
</div>
@endsection