@extends("layouts.app")
@section("content")
<div class="container mt-5">
    @include("ensenyament.form")
</div>
@endsection
